# ILI9341_kbv
Library for ILI9341 in SPI mode

Install "Adafruit_GFX.h" library

Interface is always HARD-WIRED to SPI pins

Edit serial_kbv.h to change any control pins
